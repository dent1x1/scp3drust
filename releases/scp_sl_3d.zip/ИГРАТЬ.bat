@echo off
cd /d "%~dp0"
scp_sl_3d.exe
